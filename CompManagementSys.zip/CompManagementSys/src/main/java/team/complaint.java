package team;
import java.awt.*;
import java.sql.*;

public class complaint extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    
    public complaint() {
        initComponents();
        this.setSize(870, 620);
        this.setLocationRelativeTo(null);
        jComplaintArea.setOpaque(false);           
    }
    
    String username;
    public complaint(String uname){
        initComponents();
        username = uname;
        System.out.println("------------------");
        System.out.println("username is: "+username);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jComboBoxDept = new javax.swing.JComboBox<>();
        jButtonSubmit = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jComplaintArea = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Please Describe Your Complaint Below");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 30, 380, 40);

        jComboBoxDept.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select a Department", "HouseKeeping", "Front Office", "Security", "Sales", "Food Industry", "Human Resources", "Accounting", "Kitchen", "Engeneering" }));
        getContentPane().add(jComboBoxDept);
        jComboBoxDept.setBounds(680, 40, 160, 30);

        jButtonSubmit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonSubmit.setText("Submit");
        jButtonSubmit.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jButtonSubmitStateChanged(evt);
            }
        });
        jButtonSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSubmitActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSubmit);
        jButtonSubmit.setBounds(60, 470, 150, 40);

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(410, 470, 130, 40);

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(700, 230, 130, 50);

        jComplaintArea.setColumns(20);
        jComplaintArea.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComplaintArea.setForeground(new java.awt.Color(0, 0, 0));
        jComplaintArea.setLineWrap(true);
        jComplaintArea.setRows(5);
        jComplaintArea.setWrapStyleWord(true);
        jComplaintArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jComplaintArea.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jComplaintArea.setOpaque(false);
        jComplaintArea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComplaintAreaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jComplaintArea);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(10, 20, 620, 340);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\mdamm\\OneDrive\\Documents\\NetBeansProjects\\CompManagementSys\\src\\main\\java\\team\\images\\complaint.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 870, 620);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSubmitActionPerformed
        
        String comp = jComplaintArea.getText();
        int dep = jComboBoxDept.getSelectedIndex();
        String  department = String.valueOf(dep);
        System.out.println(department);
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");   
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hosteldata", "root", "P@ssword");
            System.out.println("Connection established...");
           
//            String compQuery = ("update usercomplaints set username, department, complaint where username =?, department =?, complaint =?");
//            String compQuery = ("insert into usercomplaints (`username`, `department`, `complaint`)" + "values(?,?,?)");
            String compQuery = ("update usercomplaints set department = ?, complaint = ? where username = ?");
            
            pst = con.prepareStatement(compQuery);
//            pst.setString(1, username);
//            pst.setString(2, dep);
//            pst.setString(3, comp);   
            pst.setString(1, department);
            pst.setString(2, comp);
            pst.setString(3, username);
            
            if(pst.executeUpdate() != 0){
                System.out.println("Succesfull");
            }
        }
        
        catch (Exception e){
            System.out.println("Exception occured ");
            System.out.println(e.getMessage());
        } 
    }//GEN-LAST:event_jButtonSubmitActionPerformed

    private void jButtonSubmitStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jButtonSubmitStateChanged

    }//GEN-LAST:event_jButtonSubmitStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        System.exit(0);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComplaintAreaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComplaintAreaMouseClicked
        
    }//GEN-LAST:event_jComplaintAreaMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(complaint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(complaint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(complaint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(complaint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new complaint().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonSubmit;
    private javax.swing.JComboBox<String> jComboBoxDept;
    private javax.swing.JTextArea jComplaintArea;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
