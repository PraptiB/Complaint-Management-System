package team;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

public class timeRegist extends JPanel{
    private ImageIcon Loading_image;
    private JLabel mainlb;
    private JFrame frame;
    
    timeRegist(){
        // file path
        Loading_image = new ImageIcon("C:\\Users\\mdamm\\OneDrive\\Documents\\NetBeansProjects\\CompManagementSys\\src\\main\\java\\team"
                + "\\timeBieng2.gif");
        System.out.println("added");
        
        mainlb = new JLabel();
        setFrame();
        setProperties();
        addToPanel();
        System.out.println("properties added");
        
        try{
            Thread.sleep(4 * 1000);
            frame.dispose();
        }
        catch(Exception e){
            System.out.println("Exception " +e.getMessage());
        }
        System.out.println("end program");
    }
    
    void setFrame(){
        frame = new JFrame();
        frame.setContentPane(this);
        frame.setSize(400,150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setUndecorated(true);
        frame.setVisible(true);
    }  
        
    void setProperties(){
        this.setBackground(Color.BLACK);
        mainlb.setBounds(-205,0,605,150);
        mainlb.setIcon(Loading_image);
    }

    void addToPanel(){
        this.add(mainlb);
    }
    
    public static void main() {
        new timeRegist();
        
    }    
}
